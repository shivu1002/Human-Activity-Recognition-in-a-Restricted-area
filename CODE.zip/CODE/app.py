from flask import request, jsonify, redirect, render_template, url_for,Flask
from twilio.rest import Client

app = Flask(__name__)

@app.route('/make_call', methods=['POST'])
def make_call():
      # Your Account SID from twilio.com/console
      account_sid = 'AC30a157a0c2e9149130a18c1f5110d6c2'
      # Your Auth Token from twilio.com/console
      auth_token  = '0e0ac85d64442c8037c1a9835969687e'
      client = Client(account_sid, auth_token)

      call = client.calls.create( 
                  twiml='<response><say>hello world</say></response>',
                  to='+917744845910', 
                  from_='+15075095681'
            )
      return {'value': call.sid }



#end call
# @app.route('/end_call', methods=['POST'])
# def end_call():
#     account_sid = 'AC30a157a0c2e9149130a18c1f5110d6c2'
#     auth_token = '0e0ac85d64442c8037c1a9835969687e'
#     client = Client(account_sid, auth_token)

#     call_sid = request.form['call_sid']
#     call = client.calls(call_sid).fetch()
#     call.update(status='completed')
#     return {'value': call.sid}



@app.route('/')
def home():
      return render_template('index.html')

if __name__ == '__main__':
      app.run(debug=True)